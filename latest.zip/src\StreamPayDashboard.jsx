import { useEffect, useMemo, useRef, useState } from "react";
import { Client, ECDSA, Wallet } from "xrpl";

const COLORS = {
  ink: "#1F2D24",
  ink2: "#162119",
  muted: "#6D6A60",
  paper: "#F6F1E6",
  card: "#FFF9EC",
  line: "#E4D8C1",
  mint: "#EAD79A",
  mintDark: "#1F2D24",
  coral: "#D65A3A",
  coralDark: "#B9492E",
  butter: "#EAD79A",
  stone: "#DCCDB2",
  fog: "#8E8B83",
};

const RLUSD_CURRENCY = "524C555344000000000000000000000000000000";
const RLUSD_ISSUER = "rMxCKbEDwqr76QuheSUMdEGf4B9xJ8m5De";
const CADENCE_EMPLOYER_WALLET = "rEfcBKrxNp8mxL4xu46R5wL3ex4dpDE864";
const SOURCE_TAG = 2606250005;
const LOG_STORAGE_KEY = "cadence-debug-logs-v1";
const MAX_LOGS = 500;

const ACCESS_METHODS = [
  { value: "mnemonic", label: "BIP39 mnemonic phrase", hint: "12, 15, 18, 21, or 24 words" },
  { value: "family", label: "XRPL family seed", hint: "Usually starts with s" },
];

const isLocalDesktopApp = () =>
  typeof window !== "undefined" && (
    new URLSearchParams(window.location.search).get("desktop") === "1" ||
    /Electron|CadenceDesktop/i.test(window.navigator?.userAgent || "")
  );

const MNEMONIC_DERIVATION_OPTIONS = Array.from({ length: 10 }, (_, index) => [
  {
    label: `XRPL account ${index + 1} / Ed25519`,
    options: { derivationPath: `m/44'/144'/${index}'/0/0`, algorithm: ECDSA.ed25519 },
  },
  {
    label: `XRPL account ${index + 1} / secp256k1`,
    options: { derivationPath: `m/44'/144'/${index}'/0/0`, algorithm: ECDSA.secp256k1 },
  },
]).flat();

const TIME_UNITS = {
  seconds15: { label: "15 seconds", seconds: 15 },
  seconds30: { label: "30 seconds", seconds: 30 },
  minute: { label: "1 minute", seconds: 60 },
  minutes5: { label: "5 minutes", seconds: 5 * 60 },
  minutes15: { label: "15 minutes", seconds: 15 * 60 },
  hour: { label: "1 hour", seconds: 60 * 60 },
  day: { label: "1 day", seconds: 24 * 60 * 60 },
  week: { label: "1 week", seconds: 7 * 24 * 60 * 60 },
};

const FREQUENCIES = ["seconds15", "seconds30", "minute", "minutes5", "minutes15", "hour", "day"];

const emptyPerson = {
  name: "",
  role: "",
  email: "",
  address: "",
  weeklyPay: "16",
  frequency: "minute",
  active: false,
};

const money = (value, digits = 2) => {
  const number = Number(value) || 0;
  return `$${number.toLocaleString(undefined, {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  })}`;
};

const tokenAmount = (value) => Math.max(0, Number(value) || 0).toFixed(6);

const shortAddress = (address) =>
  address ? `${address.slice(0, 7)}...${address.slice(-5)}` : "Not added yet";

const xrplRequest = (request) =>
  new Promise((resolve, reject) => {
    const socket = new WebSocket("wss://s1.ripple.com");
    const timeout = window.setTimeout(() => {
      socket.close();
      reject(new Error("The XRPL balance check timed out."));
    }, 12000);

    socket.addEventListener("open", () => {
      socket.send(JSON.stringify({ id: Date.now(), ...request }));
    });
    socket.addEventListener("message", (event) => {
      window.clearTimeout(timeout);
      socket.close();
      const response = JSON.parse(event.data);
      if (response.status === "error" || response.error) {
        reject(new Error(response.error_message || response.error || "XRPL request failed."));
        return;
      }
      resolve(response.result);
    });
    socket.addEventListener("error", () => {
      window.clearTimeout(timeout);
      reject(new Error("Could not connect to the XRPL network."));
    });
  });

const rippleTimeToIso = (seconds) =>
  seconds ? new Date((seconds + 946684800) * 1000).toISOString() : new Date().toISOString();

const txJson = (entry) => entry.tx_json || entry.tx || {};

const deliveredIssuedAmount = (entry) => {
  const delivered = entry.meta?.delivered_amount;
  if (delivered && typeof delivered === "object") return delivered;
  const amount = txJson(entry).Amount || txJson(entry).DeliverMax;
  return amount && typeof amount === "object" ? amount : null;
};

const deliveredXrp = (entry) => {
  const delivered = entry.meta?.delivered_amount;
  if (typeof delivered === "string") return Number(delivered) / 1000000;
  const amount = txJson(entry).Amount || txJson(entry).DeliverMax;
  return typeof amount === "string" ? Number(amount) / 1000000 : 0;
};

const isRlusdAmount = (amount) =>
  amount &&
  (amount.currency === "RLUSD" || amount.currency === RLUSD_CURRENCY) &&
  amount.issuer === RLUSD_ISSUER;

const isAccountNotFoundError = (error) =>
  /actnotfound|account not found/i.test(error?.message || String(error));

const emptyIncomeProofData = (employeeWallet, employerWallet) => ({
  employeeWallet,
  employerWallet,
  sourceTag: SOURCE_TAG,
  markerRemaining: false,
  fetchedCount: 0,
  incomeRows: [],
  stats: {
    incomeCount: 0,
    totalRlusd: 0,
    excludedCount: 0,
    totalExcludedXrp: 0,
    projectedWeekly: 0,
    projectedMonthly: 0,
    projectedAnnual: 0,
    lifetimeMatches: 0,
    observedDays: 0,
  },
});

const readIncomeProofData = async (employeeWallet, employerWallet = CADENCE_EMPLOYER_WALLET) => {
  if (!employeeWallet?.startsWith("r")) {
    throw new Error("Enter or unlock a valid employee XRPL wallet first.");
  }

  let marker;
  const transactions = [];
  for (let page = 0; page < 20; page += 1) {
    let result;
    try {
      result = await xrplRequest({
        command: "account_tx",
        account: employeeWallet,
        ledger_index_min: -1,
        ledger_index_max: -1,
        binary: false,
        forward: false,
        limit: 400,
        ...(marker ? { marker } : {}),
      });
    } catch (error) {
      if (page === 0 && isAccountNotFoundError(error)) {
        return emptyIncomeProofData(employeeWallet, employerWallet);
      }
      throw error;
    }
    transactions.push(...(result.transactions || []));
    marker = result.marker;
    if (!marker) break;
  }

  const incomeRows = transactions
    .filter((entry) => {
      const tx = txJson(entry);
      const amount = deliveredIssuedAmount(entry);
      return (
        entry.meta?.TransactionResult === "tesSUCCESS" &&
        tx.TransactionType === "Payment" &&
        tx.Account === employerWallet &&
        tx.Destination === employeeWallet &&
        Number(tx.SourceTag) === SOURCE_TAG &&
        isRlusdAmount(amount)
      );
    })
    .map((entry) => {
      const tx = txJson(entry);
      const amount = deliveredIssuedAmount(entry);
      const iso = entry.close_time_iso || rippleTimeToIso(tx.date);
      return {
        time: new Date(iso).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" }),
        iso,
        amount: Number(amount.value || 0),
        hash: entry.hash,
        ledgerIndex: entry.ledger_index || tx.ledger_index,
      };
    });

  const excludedXrpRows = transactions.filter((entry) => {
    const tx = txJson(entry);
    return (
      entry.meta?.TransactionResult === "tesSUCCESS" &&
      tx.TransactionType === "Payment" &&
      tx.Destination === employeeWallet &&
      !deliveredIssuedAmount(entry) &&
      deliveredXrp(entry) > 0
    );
  });

  const totalRlusd = incomeRows.reduce((sum, row) => sum + row.amount, 0);
  const totalExcludedXrp = excludedXrpRows.reduce((sum, entry) => sum + deliveredXrp(entry), 0);
  const newest = incomeRows[0] ? new Date(incomeRows[0].iso).getTime() : Date.now();
  const oldest = incomeRows[incomeRows.length - 1] ? new Date(incomeRows[incomeRows.length - 1].iso).getTime() : newest;
  const observedDays = Math.max(1 / 24, (newest - oldest) / 86400000);
  const dailyRate = totalRlusd / observedDays;

  return {
    employeeWallet,
    employerWallet,
    sourceTag: SOURCE_TAG,
    markerRemaining: Boolean(marker),
    fetchedCount: transactions.length,
    incomeRows,
    stats: {
      incomeCount: incomeRows.length,
      totalRlusd,
      excludedCount: excludedXrpRows.length,
      totalExcludedXrp,
      projectedWeekly: dailyRate * 7,
      projectedMonthly: dailyRate * 30,
      projectedAnnual: dailyRate * 365,
      lifetimeMatches: marker ? `${incomeRows.length}+` : incomeRows.length,
      observedDays,
    },
  };
};

const normalizeMnemonic = (value) => value.trim().toLowerCase().replace(/\s+/g, " ");

const isLikelyFamilySeed = (value) => {
  const phrase = value.trim();
  return /^s[1-9A-HJ-NP-Za-km-z]{20,}$/.test(phrase) && !/\s/.test(phrase);
};

const createWalletFromInput = (method, value, expectedAddress = "") => {
  const phrase = value.trim();
  const expected = expectedAddress.trim();
  if (!phrase) {
    throw new Error("Enter your wallet phrase to continue.");
  }

  const selectedMethod = method === "auto"
    ? isLikelyFamilySeed(phrase) ? "family" : "mnemonic"
    : method;

  if (selectedMethod === "family") {
    try {
      const wallet = Wallet.fromSeed(phrase);
      if (expected && wallet.address !== expected) {
        throw new Error(`This family seed unlocks ${wallet.address}, not ${expected}. Check the wallet secret before continuing.`);
      }
      return wallet;
    } catch (error) {
      if (error?.message?.includes("not")) throw error;
      throw new Error("That does not look like a valid XRPL family seed. XRPL family seeds usually start with s.");
    }
  }

  if (isLikelyFamilySeed(phrase)) {
    throw new Error("This looks like an XRPL family seed. Choose XRPL family seed instead of BIP39 mnemonic phrase.");
  }

  const normalizedMnemonic = normalizeMnemonic(phrase);
  const wordCount = normalizedMnemonic.split(" ").filter(Boolean).length;
  if (![12, 15, 18, 21, 24].includes(wordCount)) {
    throw new Error("BIP39 mnemonic phrases are 12, 15, 18, 21, or 24 words. If your secret starts with s, use XRPL family seed.");
  }

  try {
    const candidates = MNEMONIC_DERIVATION_OPTIONS.map((item) => {
      try {
        const wallet = Wallet.fromMnemonic(normalizedMnemonic, item.options);
        return { ...item, wallet };
      } catch {
        return null;
      }
    }).filter(Boolean);

    if (expected) {
      const match = candidates.find((item) => item.wallet.address === expected);
      if (match) return match.wallet;
      const derived = candidates.slice(0, 6).map((item) => `${item.label}: ${item.wallet.address}`).join(" | ");
      throw new Error(`This phrase did not derive ${expected}. First checked addresses: ${derived}`);
    }

    return candidates[0]?.wallet || Wallet.fromMnemonic(normalizedMnemonic);
  } catch (error) {
    if (error?.message?.includes("did not derive")) throw error;
    throw new Error("Unable to parse this as a BIP39 mnemonic. Check the spelling and word order, or use XRPL family seed if your secret starts with s.");
  }
};

const buildRlusdPayment = ({ wallet, destination, amount }) => ({
  TransactionType: "Payment",
  Account: wallet.address,
  Destination: destination,
  SourceTag: SOURCE_TAG,
  Amount: {
    currency: RLUSD_CURRENCY,
    issuer: RLUSD_ISSUER,
    value: amount,
  },
});

const buildCrossmarkRlusdPayment = ({ account, destination, amount }) =>
  buildRlusdPayment({ wallet: { address: account }, destination, amount });

const responseHash = (response) =>
  response?.response?.data?.resp?.result?.hash ||
  response?.response?.data?.result?.hash ||
  response?.data?.resp?.result?.hash ||
  response?.data?.result?.hash ||
  response?.result?.hash ||
  response?.hash ||
  null;

const getCrossmark = async () => {
  const module = await import("@crossmarkio/sdk");
  return module.default || module;
};

const getXrplConnect = async () => import("@textrp/xrpl-connect");

const connectCrossmarkWallet = async () => {
  const crossmark = await getCrossmark();
  const detected = await crossmark.async.detect(2000);
  if (!detected && !crossmark.sync.isInstalled?.()) {
    throw new Error("Crossmark was not detected. Install or unlock Crossmark, then try again.");
  }
  await crossmark.async.connect(5000).catch(() => false);
  const signIn = await crossmark.async.signInAndWait();
  const address =
    signIn?.response?.data?.address ||
    signIn?.response?.data?.account ||
    signIn?.data?.address ||
    signIn?.data?.account ||
    crossmark.sync.getAddress?.();
  if (!address?.startsWith("r")) {
    throw new Error("Crossmark did not return a valid XRPL address.");
  }
  return { address, signIn };
};

const submitCrossmarkRlusdPayment = async ({ account, destination, amount }) => {
  const crossmark = await getCrossmark();
  const payment = buildCrossmarkRlusdPayment({ account, destination, amount });
  const result = await crossmark.async.signAndSubmitAndWait(payment);
  return { result, hash: responseHash(result), transaction: payment };
};

const submitXrplConnectRlusdPayment = async ({ manager, account, destination, amount }) => {
  if (!manager?.connected) {
    throw new Error("Connect an XRPL wallet first.");
  }
  const payment = buildCrossmarkRlusdPayment({ account, destination, amount });
  const result = await manager.signAndSubmit(payment);
  return { result, hash: responseHash(result), transaction: payment };
};

const submitRlusdPayment = async ({ wallet, destination, amount }) => {
  const client = new Client("wss://s1.ripple.com");
  await client.connect();
  try {
    const transaction = buildRlusdPayment({ wallet, destination, amount });
    const prepared = await client.autofill(transaction);
    const signed = wallet.sign(prepared);
    const result = await client.submitAndWait(signed.tx_blob);
    return { result, hash: signed.hash, transaction };
  } finally {
    await client.disconnect();
  }
};
const readRlusdBalance = async (address) => {
  if (!address || !address.startsWith("r")) {
    return 0;
  }

  let result;
  try {
    result = await xrplRequest({
      command: "account_lines",
      account: address,
      peer: RLUSD_ISSUER,
      ledger_index: "validated",
    });
  } catch (error) {
    if (isAccountNotFoundError(error)) return 0;
    throw error;
  }
  const line = result.lines?.find((item) =>
    (item.currency === "RLUSD" || item.currency === RLUSD_CURRENCY) && item.account === RLUSD_ISSUER
  );
  return Math.max(0, Number(line?.balance || 0));
};

const getSchedule = (person) => {
  const payMode = person.payMode || "weekly";
  const hourlyPay = Math.max(0, Number(person.hourlyPay) || 0);
  const hoursPerWeek = Math.max(0, Number(person.hoursPerWeek) || 0);
  const directWeeklyPay = Math.max(0, Number(person.weeklyPay ?? person.amount) || 0);
  const weeklyPay = payMode === "hourly" ? hourlyPay * hoursPerWeek : directWeeklyPay;
  const frequency = TIME_UNITS[person.frequency] || TIME_UNITS.minute;
  const payments = Math.max(1, Math.floor(TIME_UNITS.week.seconds / frequency.seconds));
  const perPayment = weeklyPay / payments;

  return {
    total: weeklyPay,
    payMode,
    hourlyPay,
    hoursPerWeek,
    weeklyPay,
    payments,
    perPayment,
    totalPerPayment: perPayment,
    weeklyEquivalent: weeklyPay,
    frequencyLabel: frequency.label,
    frequencySeconds: frequency.seconds,
  };
};

const getFrequencyMs = (person) => (TIME_UNITS[person.frequency] || TIME_UNITS.minute).seconds * 1000;

const addHistoryItem = (setter, item) => {
  setter((current) => [
    {
      id: `history-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      at: new Date().toISOString(),
      ...item,
    },
    ...current,
  ]);
};

const safeLogPayload = (value) => {
  if (value instanceof Error) {
    return { name: value.name, message: value.message, stack: value.stack };
  }
  if (Array.isArray(value)) {
    return value.map(safeLogPayload);
  }
  if (!value || typeof value !== "object") {
    return value;
  }

  return Object.fromEntries(Object.entries(value).map(([key, item]) => {
    const lower = key.toLowerCase();
    if (lower.includes("seed") || lower.includes("phrase") || lower.includes("secret") || lower.includes("password") || lower.includes("accessinput")) {
      return [key, "[redacted]"];
    }
    return [key, safeLogPayload(item)];
  }));
};

const loadStoredLogs = () => {
  try {
    return JSON.parse(window.localStorage.getItem(LOG_STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
};

function Brand({ compact = false }) {
  return (
    <div className="brand-lockup">
      <CadenceMark className="brand-mark" />
      <div>
        <div className="brand-word" style={{ fontSize: compact ? 22 : 30 }}>Cadence</div>
        <div className="brand-xrp">ON XRP</div>
        {!compact && <div className="brand-tagline">Real-time payroll. Streaming income.</div>}
      </div>
    </div>
  );
}

function CadenceMark({ className = "" }) {
  return (
    <span className={className} aria-hidden="true">
      <svg viewBox="0 0 64 64" fill="none">
        <path d="M44 16a20 20 0 1 0 0 32" />
        <path d="M49 10a28 28 0 1 0 0 44" />
        <path d="M39 24a11 11 0 1 0 0 16" />
      </svg>
    </span>
  );
}

function BrandPattern({ variant = "wave" }) {
  if (variant === "dots") return <div className="brand-pattern pattern-dots" aria-hidden="true" />;
  if (variant === "rings") return <div className="brand-pattern pattern-rings" aria-hidden="true" />;
  if (variant === "lines") return <div className="brand-pattern pattern-lines" aria-hidden="true" />;
  return (
    <div className="brand-pattern pattern-wave" aria-hidden="true">
      <svg viewBox="0 0 1200 118" preserveAspectRatio="none">
        <path d="M0 72 C130 92 238 92 360 66 S590 20 760 44 S1030 78 1200 46" />
        <path d="M0 62 C130 84 242 86 365 62 S594 18 762 36 S1032 70 1200 38" />
        <path d="M0 52 C132 76 246 80 370 58 S598 18 764 30 S1034 62 1200 32" />
        <path d="M0 42 C134 68 250 72 375 54 S602 20 766 26 S1036 54 1200 28" />
        <path d="M0 32 C136 58 254 64 380 50 S606 24 768 24 S1038 48 1200 28" />
        <path d="M0 22 C138 50 258 54 385 46 S610 30 770 26 S1040 44 1200 34" />
      </svg>
    </div>
  );
}

function StreamWidget({
  label,
  amount,
  subcopy,
  address,
  primaryAction,
  secondaryAction,
  stats = [],
  compact = false,
}) {
  const display = money(amount, 4);
  const [whole, cents = "0000"] = display.replace("$", "").split(".");
  return (
    <section className={`stream-widget ${compact ? "stream-widget-compact" : ""}`}>
      <div className="stream-widget-rings" aria-hidden="true" />
      <div className="stream-top">
        <div>
          <p className="stream-label">{label}</p>
          <div className="stream-amount">${whole}<span>.{cents}</span></div>
          <p className="stream-subcopy">{subcopy}</p>
        </div>
        <div className="stream-live"><span className="online-dot" />Live</div>
      </div>
      <svg className="stream-wave" viewBox="0 0 400 64" preserveAspectRatio="none" aria-hidden="true">
        <path className="stream-wave-base" d="M0,32 L400,32" />
        <path className="stream-wave-line" d="M0,32 C65,36 110,36 150,32 C178,32 182,12 195,32 C205,49 214,49 226,32 C266,28 315,34 400,32" />
        <circle cx="200" cy="32" r="4" />
      </svg>
      <div className="stream-stats">
        {stats.map((item) => (
          <div key={item.label}>
            <strong>{item.value}</strong>
            <span>{item.label}</span>
          </div>
        ))}
      </div>
      <div className="stream-footer">
        <code>{address || "No wallet connected"}</code>
        <div className="stream-actions">
          {primaryAction}
          {secondaryAction}
        </div>
      </div>
    </section>
  );
}

function Button({ children, kind = "primary", ...props }) {
  return <button className={`button button-${kind}`} {...props}>{children}</button>;
}

function Field({ label, children, help }) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
      {help && <span className="field-help">{help}</span>}
    </label>
  );
}

function Intro({ method, setMethod, accessInput, setAccessInput, expectedAddress, setExpectedAddress, onSubmit, error, isLocal, connectorRef, xrplManager }) {
  const [showWalletSecret, setShowWalletSecret] = useState(false);

  useEffect(() => {
    if (!isLocal && connectorRef?.current && xrplManager) {
      connectorRef.current.setWalletManager(xrplManager);
    }
  }, [connectorRef, isLocal, xrplManager]);

  return (
    <div className="center-screen intro-screen">
      <div className="intro-decoration decoration-one" />
      <div className="intro-decoration decoration-two" />
      <BrandPattern variant="wave" />
      <BrandPattern variant="dots" />
      <div className="intro-card">
        <Brand />
        <BrandPattern variant="rings" />
        <p className="eyebrow">{isLocal ? "Import wallet" : "Connect XRPL wallet"}</p>
        <h1>{isLocal ? <>Your wallet,<br /><em>imported locally.</em></> : <>Your wallet,<br /><em>exactly as selected.</em></>}</h1>
        <p className="intro-copy">
          {isLocal
            ? "Cadence unlocks the local app with a BIP39 mnemonic seed phrase or XRPL family seed, then signs payments on this device."
            : "Cadence connects through XRPL Connect so you can use supported XRP wallets including Xaman, Crossmark, GemWallet, and Xyra."}
        </p>
        <form className="intro-connect-form" onSubmit={(event) => { event.preventDefault(); onSubmit(); }}>
          {error && <div className="error-message">{error}</div>}
          {isLocal && (
            <>
              <Field label="Wallet import type">
                <select value={method} onChange={(event) => setMethod(event.target.value)}>
                  {ACCESS_METHODS.map((item) => <option value={item.value} key={item.value}>{item.label} - {item.hint}</option>)}
                </select>
              </Field>
              <Field label="Mnemonic seed phrase or family seed">
                <div className="secret-input-wrap">
                  <input
                    type={showWalletSecret ? "text" : "password"}
                    value={accessInput}
                    onChange={(event) => setAccessInput(event.target.value)}
                    placeholder="12/24 words or s..."
                    autoComplete="off"
                    spellCheck="false"
                  />
                  <button
                    type="button"
                    className="secret-toggle"
                    onClick={() => setShowWalletSecret((showing) => !showing)}
                  >
                    {showWalletSecret ? "Hide" : "Show"}
                  </button>
                </div>
              </Field>
              <Field label="Expected public address" help="Optional. Use this to confirm the secret opens the intended r... wallet.">
                <input value={expectedAddress} onChange={(event) => setExpectedAddress(event.target.value)} placeholder="r..." autoComplete="off" spellCheck="false" />
              </Field>
            </>
          )}
          {!isLocal && (
            <xrpl-wallet-connector
              ref={connectorRef}
              class="xrpl-connector"
              wallets="xaman,crossmark,gemwallet,xyra"
              primary-wallet="xaman"
              background-color="#fffdf8"
            />
          )}
          <Button type="submit">{isLocal ? "Import wallet" : "Connect XRPL wallet"} <span>{">"}</span></Button>
        </form>
        <div className="intro-note">
          {isLocal
            ? "The desktop app only offers mnemonic seed phrase or XRPL family seed import. Crossmark is reserved for the web version."
            : "Cadence never asks for your seed phrase in the web flow. Your connected XRPL wallet signs each transaction request."}
        </div>
      </div>
    </div>
  );
}

function FundingModal({ onClose }) {
  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="modal-card">
        <button className="modal-close" onClick={onClose} aria-label="Close">x</button>
        <CadenceMark className="modal-icon brand-mark" />
        <p className="eyebrow">Your wallet is ready</p>
        <h2>No RLUSD yet.</h2>
        <p className="section-copy">Fund the wallet first, then Cadence can read the balance and help you plan payments.</p>
        <div className="funding-steps">
          <div><b>1</b><span>Use a trusted exchange or RLUSD onramp that supports the XRPL network.</span></div>
          <div><b>2</b><span>Copy your public XRPL address and verify the RLUSD issuer before sending.</span></div>
          <div><b>3</b><span>Come back and refresh the balance. Never share your secret phrase.</span></div>
        </div>
        <Button kind="secondary" onClick={onClose}>Go to dashboard</Button>
      </div>
    </div>
  );
}

function PersonEditor({ person, onSave, onCancel }) {
  const [draft, setDraft] = useState({ ...emptyPerson, ...(person || {}) });
  const update = (key, value) => setDraft((current) => ({ ...current, [key]: value }));
  const hourlyMode = (draft.payMode || "weekly") === "hourly";

  return (
    <form className="editor-card" onSubmit={(event) => { event.preventDefault(); onSave(draft); }}>
      <div className="editor-heading">
        <div><p className="eyebrow">People</p><h3>{person?.id ? "Edit person" : "Add a person"}</h3></div>
        <button type="button" className="text-button" onClick={onCancel}>Cancel</button>
      </div>
      <div className="editor-grid">
        <Field label="Name"><input required value={draft.name} onChange={(event) => update("name", event.target.value)} placeholder="Alex Morgan" /></Field>
        <Field label="Role"><input value={draft.role} onChange={(event) => update("role", event.target.value)} placeholder="Designer" /></Field>
        <Field label="Email"><input type="email" value={draft.email} onChange={(event) => update("email", event.target.value)} placeholder="alex@example.com" /></Field>
        <Field label="Public XRPL address" help="Required only for a real payment."><input value={draft.address} onChange={(event) => update("address", event.target.value)} placeholder="r..." /></Field>
      </div>
      <div className="pay-plan-box">
        <div className="pay-plan-title">Weekly payment cadence</div>
        <label className="mode-toggle">
          <input type="checkbox" checked={hourlyMode} onChange={(event) => update("payMode", event.target.checked ? "hourly" : "weekly")} />
          <span>{hourlyMode ? "Hourly pay" : "Weekly salary"}</span>
        </label>
        <div className="editor-grid plan-grid">
          {hourlyMode ? (
            <>
              <Field label="Hourly RLUSD pay" help="Rate per hour."><div className="input-with-symbol"><span>$</span><input type="number" min="0" step="0.01" required value={draft.hourlyPay ?? "20"} onChange={(event) => update("hourlyPay", event.target.value)} /></div></Field>
              <Field label="Hours per week" help="Used to calculate weekly total."><input type="number" min="0" step="0.25" required value={draft.hoursPerWeek ?? "40"} onChange={(event) => update("hoursPerWeek", event.target.value)} /></Field>
            </>
          ) : (
            <Field label="Weekly RLUSD pay" help="The total this person should receive each week."><div className="input-with-symbol"><span>$</span><input type="number" min="0" step="0.01" required value={draft.weeklyPay ?? draft.amount ?? "16"} onChange={(event) => update("weeklyPay", event.target.value)} /></div></Field>
          )}
          <Field label="Pay frequency" help="Cadence divides the weekly total across this interval."><select value={draft.frequency} onChange={(event) => update("frequency", event.target.value)}>{FREQUENCIES.map((key) => <option key={key} value={key}>Every {TIME_UNITS[key].label}</option>)}</select></Field>
        </div>
        <ScheduleSummary person={draft} />
      </div>
      <Button type="submit">Save cadence <span>{">"}</span></Button>
    </form>
  );
}

function ScheduleSummary({ person }) {
  const schedule = getSchedule(person);
  return (
    <div className="schedule-summary">
      <div><span className="summary-label">Each payment</span><strong>{money(schedule.perPayment, 6)}</strong></div>
      <div><span className="summary-label">Payments per week</span><strong>{schedule.payments.toLocaleString()}</strong></div>
      <div><span className="summary-label">Weekly total</span><strong>{money(schedule.weeklyPay, 2)}</strong></div>
    </div>
  );
}

function PeopleList({ people, selectedId, onSelect, onAdd }) {
  return (
    <div className="people-card">
      <div className="card-heading"><div><p className="eyebrow">Your people</p><h2>{people.length ? "Payment plans" : "Start with one person"}</h2></div><Button kind="small" onClick={onAdd}>+ Add person</Button></div>
      {people.length === 0 ? (
        <div className="empty-people"><div className="empty-scribble">*</div><p>Add someone to see their payment plan here.</p><Button kind="secondary" onClick={onAdd}>Add your first person</Button></div>
      ) : (
        <div className="people-list">
          {people.map((person) => {
            const schedule = getSchedule(person);
            return <button key={person.id} className={`person-row ${selectedId === person.id ? "selected" : ""}`} onClick={() => onSelect(person.id)}>
              <span className="avatar">{person.name.slice(0, 1).toUpperCase()}</span>
              <span className="person-info"><b>{person.name}</b><small>{person.role || "Person"}</small></span>
              <span className="person-amount"><b>{money(schedule.perPayment, 4)}</b><small>every {schedule.frequencyLabel}</small></span>
              <span className={`status-dot ${person.active ? "on" : ""}`} />
            </button>;
          })}
        </div>
      )}
    </div>
  );
}

function PersonDetails({ person, onEdit, onToggle, onPay, walletReady, paymentMessage }) {
  const schedule = getSchedule(person);
  const paidCount = Number(person.paidCount || 0);
  const nextRun = person.nextRunAt ? new Date(person.nextRunAt).toLocaleString() : "Not scheduled";
  return (
    <div className="details-card">
      <div className="details-top"><div className="large-avatar">{person.name.slice(0, 1).toUpperCase()}</div><div><p className="eyebrow">Selected person</p><h2>{person.name}</h2><p className="muted-line">{person.role || "No role added"} {person.email ? ` ${person.email}` : ""}</p></div><button className="text-button edit-button" onClick={onEdit}>Edit</button></div>
      <div className="address-line"><span>Destination</span><code>{shortAddress(person.address)}</code></div>
      <div className="detail-highlight"><div><span className="eyebrow">Weekly pay</span><strong>{money(schedule.weeklyPay)}</strong><small>recipient amount across 1 week</small></div><div className="highlight-arrow">{">"}</div><div><span className="eyebrow">Each payout</span><strong>{money(schedule.perPayment, 6)}</strong><small>sent directly to the destination wallet</small></div></div>
      <div className="plan-meter"><div><span>Installments sent</span><strong>{paidCount} / {schedule.payments.toLocaleString()}</strong></div><div><span>Next send</span><strong>{nextRun}</strong></div><div><span>Recipient debit</span><strong>{money(schedule.totalPerPayment, 6)}</strong></div><div><span>Source tag</span><strong>{SOURCE_TAG}</strong></div></div>
      <div className="details-actions"><Button kind={person.active ? "secondary" : "primary"} onClick={onToggle}>{person.active ? "Pause plan" : "Start plan"}</Button><Button kind="secondary" onClick={onPay} disabled={!walletReady || !person.address.startsWith("r")}>Pay one installment</Button></div>
      {!walletReady && <p className="inline-note">Connect a wallet first to make an on-chain payment.</p>}
      {walletReady && !person.address.startsWith("r") && <p className="inline-note">Add a public XRPL destination address before paying.</p>}
      {paymentMessage && <div className="success-message">{paymentMessage}</div>}
      <div className="safe-payment-note"><span>?</span> Cadence submits one RLUSD payment per interval to the designated destination wallet. Scheduled plans continue until all weekly installments have been sent or you pause the plan.</div>
    </div>
  );
}

function IncomeVerification({ walletAddress, employee, onBack, onExportLogs, onReset }) {
  const [ledgerOpen, setLedgerOpen] = useState(false);
  const [proofData, setProofData] = useState(null);
  const [proofLoading, setProofLoading] = useState(false);
  const [proofError, setProofError] = useState("");
  const connectedWallet = walletAddress?.startsWith("r") ? walletAddress : "";
  const employerWallet = CADENCE_EMPLOYER_WALLET;
  const stats = proofData?.stats || {
    incomeCount: 0,
    totalRlusd: 0,
    excludedCount: 0,
    totalExcludedXrp: 0,
    projectedWeekly: 0,
    projectedMonthly: 0,
    projectedAnnual: 0,
    lifetimeMatches: 0,
    observedDays: 0,
  };
  const incomeRows = proofData?.incomeRows || [];
  const generatedAt = new Date().toLocaleDateString([], { year: "numeric", month: "short", day: "numeric" });
  const documentId = connectedWallet ? `CADENCE-INC-${connectedWallet.slice(0, 6).toUpperCase()}-${connectedWallet.slice(-6).toUpperCase()}` : "CADENCE-INC-CONNECT";

  const refreshProof = async () => {
    setProofLoading(true);
    setProofError("");
    try {
      const data = await readIncomeProofData(connectedWallet, employerWallet);
      setProofData(data);
    } catch (error) {
      setProofError(error?.message || "Could not read income transactions from the XRP Ledger.");
    } finally {
      setProofLoading(false);
    }
  };

  useEffect(() => {
    setProofData(null);
    refreshProof();
  }, [connectedWallet]);

  const downloadCsv = () => {
    const lines = ["time,amount_rlusd,tx_hash,ledger_index", ...incomeRows.map((row) => `${row.iso},${row.amount.toFixed(6)},${row.hash},${row.ledgerIndex || ""}`)];
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "cadence-income-proof.csv";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="app-shell proof-app">
      <header className="topbar proof-topbar">
        <Brand compact />
        <div className="topbar-right">
          <div className="wallet-chip"><span className="online-dot" />Connected wallet {shortAddress(connectedWallet)}</div>
          <Button kind="ghost" onClick={onExportLogs}>Download support file</Button>
          <Button kind="ghost" onClick={onBack}>Back to dashboard</Button>
          <Button kind="ghost" onClick={onReset}>Change wallet</Button>
        </div>
      </header>
      <main className="proof-content">
        <div className="proof-heading">
          <div>
            <p className="eyebrow"><span className="online-dot" /> Certified financial document</p>
            <h1>Income verification</h1>
            <p>On-chain proof of income, compiled from real XRP Ledger transactions for the currently connected wallet.</p>
          </div>
          <span className="proof-pill">Generated {generatedAt}</span>
        </div>

        <section className="proof-reference">
          <div className="proof-reference-top">
            <div>
              <p>Document reference</p>
              <strong>{documentId}</strong>
            </div>
            <span><i />Verified on-chain</span>
          </div>
          <div className="proof-reference-grid">
            <div><small>Connected wallet / payee</small><b>{connectedWallet || "No wallet connected"}</b></div>
            <div><small>Payer (employer wallet)</small><b>{employerWallet}</b></div>
            <div><small>Source tag</small><b>{SOURCE_TAG}</b></div>
            <div><small>Ledger</small><b>XRP Ledger - Mainnet</b></div>
          </div>
        </section>

        <div className="proof-stat-grid">
          <section className="proof-card"><p className="eyebrow">Verified payments</p><strong>{stats.incomeCount}</strong><span>tagged incoming RLUSD transfers from Cadence</span></section>
          <section className="proof-card"><p className="eyebrow">RLUSD received</p><strong>${stats.totalRlusd.toFixed(6)}</strong><span>over the verified window below</span></section>
          <section className="proof-card"><p className="eyebrow">Other on-chain activity</p><strong>{stats.excludedCount}</strong><span>XRP txns ({stats.totalExcludedXrp.toFixed(6)} XRP), excluded from income</span></section>
        </div>

        {(proofLoading || proofError || stats.incomeCount === 0) && (
          <section className={`proof-status ${proofError ? "error" : ""}`}>
            {proofLoading ? "Reading real wallet transactions from XRPL mainnet..." : proofError || "No Cadence-tagged RLUSD income transactions were found for this wallet yet."}
          </section>
        )}

        <section className="proof-card proof-projection">
          <p className="eyebrow">Projected income, at verified rate</p>
          <h2>Extrapolated from {stats.incomeCount} confirmed payments</h2>
          <div className="proof-projection-grid">
            <div><small>Weekly</small><strong>${stats.projectedWeekly.toFixed(2)}</strong></div>
            <div><small>Monthly</small><strong>${stats.projectedMonthly.toFixed(2)}</strong></div>
            <div><small>Annual</small><strong>${stats.projectedAnnual.toFixed(2)}</strong></div>
          </div>
          <p>Lifetime on-chain record shows {stats.lifetimeMatches} matching incoming payments in the fetched ledger window; projections use the observed timing across {stats.observedDays.toFixed(2)} day(s) of verified data.</p>
        </section>

        <section className="proof-card proof-ledger">
          <div className="proof-ledger-head">
            <div><p className="eyebrow">Verified payment ledger</p><h2>{stats.incomeCount} employer-tagged RLUSD payments</h2></div>
            <div><Button kind="secondary" onClick={refreshProof} disabled={proofLoading}>{proofLoading ? "Reading..." : "Refresh"}</Button><Button kind="secondary" onClick={downloadCsv} disabled={!incomeRows.length}>Download CSV</Button><Button kind="ghost" onClick={() => setLedgerOpen((open) => !open)}>{ledgerOpen ? "Hide full ledger" : "View full ledger"}</Button></div>
          </div>
          {ledgerOpen && (
            <div className="employee-table-wrap">
              <table className="employee-table">
                <thead><tr><th>Time</th><th>Amount</th><th>Transaction</th><th>Verify</th></tr></thead>
                <tbody>
                  {incomeRows.map((row, index) => (
                    <tr key={`${row.hash}-${row.ledgerIndex || index}`}>
                      <td>{row.time}</td>
                      <td>${row.amount.toFixed(6)}</td>
                      <td>{row.hash.slice(0, 10)}...{row.hash.slice(-6)}</td>
                      <td><a href={`https://xrpscan.com/tx/${row.hash}`} target="_blank" rel="noreferrer">xrpscan</a></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <p className="proof-disclaimer">This statement reflects payments retrieved directly from the XRP Ledger for the payee wallet above, filtered to transfers carrying Cadence's source tag from its disbursing wallet. Generated for self-serve verification purposes; not a bank-issued statement.</p>
      </main>
    </div>
  );
}

function EmployeeDashboard({ walletAddress, rlusdBalance, balanceLoading, onRefreshBalance, people, onBack, onExportLogs, onReset }) {
  const connectedWallet = walletAddress?.startsWith("r") ? walletAddress : "";
  const samplePerson = {
    name: "Connected wallet",
    role: "Employee",
    address: walletAddress,
    weeklyPay: "0",
    frequency: "seconds15",
    paidCount: 0,
  };
  const employee = people.find((person) => person.active) || people[0] || samplePerson;
  const schedule = getSchedule({ ...employee, frequency: employee.frequency || "seconds15" });
  const [withdrawn, setWithdrawn] = useState(false);
  const [employeeView, setEmployeeView] = useState("dashboard");
  const [employeeProofData, setEmployeeProofData] = useState(null);
  const [employeeProofLoading, setEmployeeProofLoading] = useState(false);
  const [employeeProofError, setEmployeeProofError] = useState("");

  useEffect(() => {
    setWithdrawn(false);
  }, [employee.id]);

  useEffect(() => {
    let cancelled = false;
    const refreshEmployeeProof = async () => {
      if (!connectedWallet) {
        setEmployeeProofData(null);
        setEmployeeProofError("Connect a wallet to read employee dashboard data.");
        return;
      }
      setEmployeeProofLoading(true);
      setEmployeeProofError("");
      setEmployeeProofData(null);
      try {
        const data = await readIncomeProofData(connectedWallet, CADENCE_EMPLOYER_WALLET);
        if (!cancelled) setEmployeeProofData(data);
      } catch (error) {
        if (!cancelled) setEmployeeProofError(error?.message || "Could not read employee wallet transactions.");
      } finally {
        if (!cancelled) setEmployeeProofLoading(false);
      }
    };

    refreshEmployeeProof();
    return () => {
      cancelled = true;
    };
  }, [connectedWallet]);

  const incomeRows = employeeProofData?.incomeRows || [];
  const newestPayment = incomeRows[0] || null;
  const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const verifiedLastSevenDays = incomeRows
    .filter((row) => new Date(row.iso).getTime() >= sevenDaysAgo)
    .reduce((sum, row) => sum + row.amount, 0);
  const expectedWeekly = schedule.weeklyPay > 0 ? schedule.weeklyPay : verifiedLastSevenDays;
  const progressPct = expectedWeekly > 0 ? Math.min(100, (verifiedLastSevenDays / expectedWeekly) * 100) : 0;
  const displayBalance = money(rlusdBalance, 2);
  const [balanceWhole, balanceCents = "00"] = displayBalance.replace("$", "").split(".");
  const employeeName = employee.name || "Connected wallet";
  const employerWallet = "rEfcBKr...DE864";

  if (employeeView === "proof") {
    return <IncomeVerification walletAddress={walletAddress} employee={employee} onBack={() => setEmployeeView("dashboard")} onExportLogs={onExportLogs} onReset={onReset} />;
  }

  return (
    <div className="app-shell employee-app">
      <BrandPattern variant="wave" />
      <BrandPattern variant="dots" />
      <header className="topbar">
        <Brand compact />
        <div className="topbar-right">
          <div className="wallet-chip"><span className="online-dot" />{shortAddress(walletAddress || employee.address)}</div>
          <Button kind="ghost" onClick={onBack}>Employer dashboard</Button>
          <Button kind="ghost" onClick={() => setEmployeeView("proof")}>Income proof</Button>
          <Button kind="ghost" onClick={onExportLogs}>Support file</Button>
          <Button kind="ghost" onClick={onReset}>Change wallet</Button>
        </div>
      </header>
      <main className="dashboard-content employee-content">
        <div className="employee-hero">
          <div>
            <p className="eyebrow"><span className="online-dot" /> Good to see you, {employeeName}</p>
            <h1>Your pay, streaming in</h1>
            <p className="muted-line">Real RLUSD balance and Cadence-tagged income for the currently connected wallet.</p>
          </div>
          <div className="live-pill"><span className="online-dot" />Employee dashboard</div>
        </div>

        <StreamWidget
          label="Available balance RLUSD"
          amount={rlusdBalance}
          subcopy={balanceLoading ? "Reading XRPL balance..." : `Read from ${shortAddress(connectedWallet)} on XRPL mainnet`}
          address={connectedWallet}
          stats={[
            { value: money(verifiedLastSevenDays, 2), label: "7 day income" },
            { value: newestPayment ? money(newestPayment.amount, 4) : "$0.0000", label: "Latest payment" },
            { value: `${incomeRows.length}`, label: "Verified txns" },
          ]}
          primaryAction={<Button kind="secondary" onClick={onRefreshBalance} disabled={balanceLoading}>{balanceLoading ? "Reading..." : "Refresh balance"}</Button>}
          secondaryAction={<Button kind="soft" onClick={() => setWithdrawn(true)} disabled={withdrawn}>{withdrawn ? "Withdrawal queued" : "Withdraw"}</Button>}
        />
        {withdrawn && <p className="inline-note">Funds settle in your linked account shortly.</p>}

        <div className="employee-stat-grid">
          <section className="employee-card">
            <p className="eyebrow">Verified last 7 days</p>
            <strong>{money(verifiedLastSevenDays)}</strong>
            <span>{employeeProofLoading ? "Reading Cadence-tagged payments..." : `from ${incomeRows.length.toLocaleString()} fetched income payment(s)`}</span>
            <div className="employee-progress"><div style={{ width: `${progressPct}%` }} /></div>
            <small>{expectedWeekly > 0 ? `${money(verifiedLastSevenDays)} / ${money(expectedWeekly)} reference weekly amount` : "No weekly reference amount yet"}</small>
          </section>
          <section className="employee-card">
            <p className="eyebrow">Latest verified payment</p>
            <strong>{newestPayment ? money(newestPayment.amount, 6) : "$0.000000"}</strong>
            <span>{newestPayment ? newestPayment.time : employeeProofError || "No Cadence-tagged RLUSD payment found"}</span>
            <div className="employee-meta-row">
              <div><small>Source tag</small><b>{SOURCE_TAG}</b></div>
              <div><small>Paid by</small><b>{employerWallet}</b></div>
            </div>
          </section>
        </div>

        <section className="employee-card employee-history-card">
          <div className="card-heading">
            <div><p className="eyebrow">Payment history</p><h2>Recent RLUSD received</h2></div>
            <div className="card-actions"><span className="employee-live-tag">{incomeRows.slice(0, 8).length} shown</span><Button kind="secondary" onClick={() => setEmployeeView("proof")}>Open income proof</Button></div>
          </div>
          <div className="employee-table-wrap">
            <table className="employee-table">
              <thead><tr><th>Time</th><th>Amount</th><th>Transaction</th><th>Status</th></tr></thead>
              <tbody>
                {incomeRows.slice(0, 8).map((row, index) => (
                  <tr key={`${row.hash}-${row.ledgerIndex || index}`}>
                    <td>{row.time}</td>
                    <td>${row.amount.toFixed(6)}</td>
                    <td>{row.hash.slice(0, 10)}...{row.hash.slice(-6)}</td>
                    <td><span>Verified</span></td>
                  </tr>
                ))}
                {!incomeRows.length && (
                  <tr><td colSpan="4">{employeeProofLoading ? "Reading XRPL payment history..." : employeeProofError || "No Cadence-tagged RLUSD payments found for this connected wallet."}</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}

function Dashboard({ walletAddress, walletProvider, rlusdBalance, balanceLoading, onRefreshBalance, onOpenFunding, onReset, people, onAdd, selectedId, onSelect, onSave, onEdit, onToggle, onPay, paymentMessage, history, onExportLogs, onOpenEmployee }) {
  const selectedPerson = people.find((person) => person.id === selectedId);
  const walletReady = Boolean((walletProvider === "xrplconnect" || walletProvider === "local") && walletAddress?.startsWith("r"));
  const providerLabel = walletProvider === "xrplconnect" ? "XRPL wallet" : "Local wallet";
  const signingCopy = walletProvider === "xrplconnect"
    ? "Create payment plans, review each destination, and confirm each transaction in the connected XRPL wallet."
    : "Create payment plans, review each destination, and sign each transaction with the imported local wallet.";
  const payerCopy = walletProvider === "xrplconnect"
    ? "This is the active XRPL Connect wallet. Cadence never stores a seed phrase."
    : "This wallet was imported from a mnemonic seed phrase or XRPL family seed for local signing.";
  return (
    <div className="app-shell">
      <BrandPattern variant="wave" />
      <BrandPattern variant="rings" />
      <header className="topbar"><Brand compact /><div className="topbar-right"><div className="wallet-chip"><span className="online-dot" />{shortAddress(walletAddress)}</div><Button kind="ghost" onClick={onOpenEmployee}>Employee dashboard</Button><Button kind="ghost" onClick={onExportLogs}>Support file</Button><Button kind="ghost" onClick={onReset}>Change wallet</Button></div></header>
      <main className="dashboard-content">
        <div className="welcome-row"><div><p className="eyebrow">Employer dashboard</p><h1>Send RLUSD with confidence</h1><p className="muted-line">{signingCopy}</p></div><div className="live-pill"><span className="online-dot" />{providerLabel} connected</div></div>
        <StreamWidget
          label="Employer wallet balance"
          amount={rlusdBalance}
          subcopy={balanceLoading ? "Reading XRPL balance..." : signingCopy}
          address={walletAddress ? shortAddress(walletAddress) : "No wallet connected"}
          stats={[
            { value: people.length.toLocaleString(), label: "Payment plans" },
            { value: selectedPerson ? money(getSchedule(selectedPerson).perPayment, 4) : "$0.0000", label: "Next payout" },
            { value: SOURCE_TAG, label: "Source tag" },
          ]}
          primaryAction={<Button kind="secondary" onClick={onRefreshBalance} disabled={balanceLoading}>{balanceLoading ? "Reading..." : "Refresh balance"}</Button>}
          secondaryAction={rlusdBalance <= 0 ? <Button kind="soft" onClick={onOpenFunding}>Add RLUSD</Button> : null}
        />
        <section className="payer-strip"><div><p className="eyebrow">Payment wallet</p><strong>{shortAddress(walletAddress)}</strong><span>{payerCopy}</span></div><Button kind="secondary" onClick={onReset}>Change wallet</Button></section>
        <div className="content-grid"><PeopleList people={people} selectedId={selectedId} onSelect={onSelect} onAdd={onAdd} />{selectedPerson ? <PersonDetails person={selectedPerson} onEdit={() => onEdit(selectedPerson)} onToggle={() => onToggle(selectedPerson.id)} onPay={() => onPay(selectedPerson)} walletReady={walletReady} paymentMessage={paymentMessage} /> : <div className="details-card details-empty"><div className="empty-sun">*</div><h2>Add a recipient to begin.</h2><p>Create a payment plan with a verified XRPL destination address before sending RLUSD.</p><Button onClick={onAdd}>Create payment plan</Button></div>}</div>
        <section className="history-panel"><div className="card-heading"><div><p className="eyebrow">Payment activity</p><h2>Recent actions</h2></div><Button kind="small" onClick={onExportLogs}>Download support file</Button></div>{history.length === 0 ? <p className="muted-line">No payment activity yet.</p> : <div className="history-list">{history.slice(0, 8).map((item) => <div className={`history-row ${item.status}`} key={item.id}><div><b>{item.title}</b><span>{item.detail}</span></div><time>{new Date(item.at).toLocaleString()}</time></div>)}</div>}</section>
        <p className="footer-note">RLUSD is a dollar-denominated token on the XRP Ledger. Network fees, issuer details, and wallet confirmations should always be checked before sending.</p>
      </main>
    </div>
  );
}

export default function CadenceDashboard() {
  const [screen, setScreen] = useState("intro");
  const [method, setMethod] = useState("mnemonic");
  const [accessInput, setAccessInput] = useState("");
  const [expectedAddress, setExpectedAddress] = useState("");
  const [walletAddress, setWalletAddress] = useState("");
  const [rlusdBalance, setRlusdBalance] = useState(0);
  const [balanceLoading, setBalanceLoading] = useState(false);
  const [setupError, setSetupError] = useState("");
  const [showFunding, setShowFunding] = useState(false);
  const [signingWallet, setSigningWallet] = useState(null);
  const [walletProvider, setWalletProvider] = useState("");
  const [people, setPeople] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingPerson, setEditingPerson] = useState(null);
  const [paymentMessage, setPaymentMessage] = useState("");
  const [history, setHistory] = useState([]);
  const [debugLogs, setDebugLogs] = useState(loadStoredLogs);
  const [dashboardView, setDashboardView] = useState("employer");
  const autoPayingRef = useRef(false);
  const xrplConnectorRef = useRef(null);
  const xrplConnectManagerRef = useRef(null);
  const [xrplConnectManager, setXrplConnectManager] = useState(null);
  const localDesktop = useMemo(() => isLocalDesktopApp(), []);

  const selectedPerson = useMemo(() => people.find((person) => person.id === selectedId), [people, selectedId]);

  const logEvent = (event, payload = {}) => {
    const entry = {
      id: `log-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      at: new Date().toISOString(),
      event,
      payload: safeLogPayload(payload),
    };
    setDebugLogs((current) => {
      const next = [entry, ...current].slice(0, MAX_LOGS);
      window.localStorage.setItem(LOG_STORAGE_KEY, JSON.stringify(next));
      return next;
    });
    console.info(`[Cadence] ${event}`, entry.payload);
    return entry;
  };

  const exportLogs = () => {
    const logText = JSON.stringify({
      exportedAt: new Date().toISOString(),
      app: "Cadence",
      sourceTag: SOURCE_TAG,
      logs: debugLogs,
      people: people.map((person) => ({
        id: person.id,
        name: person.name,
        address: person.address ? shortAddress(person.address) : "",
        active: person.active,
        schedule: getSchedule(person),
        paidCount: person.paidCount || 0,
        nextRunAt: person.nextRunAt || null,
      })),
    }, null, 2);
    const blob = new Blob([logText], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `cadence-logs-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
    link.click();
    URL.revokeObjectURL(url);
    logEvent("logs.exported", { count: debugLogs.length });
  };

  const clearLogs = () => {
    window.localStorage.removeItem(LOG_STORAGE_KEY);
    setDebugLogs([]);
    console.info("[Cadence] logs.cleared");
  };

  const refreshBalance = async (address = walletAddress, options = {}) => {
    const showFundingWhenEmpty = options.showFundingWhenEmpty ?? true;
    logEvent("balance.refresh.started", { address: address ? shortAddress(address) : "none" });
    if (!address || !address.startsWith("r")) {
      setRlusdBalance(0);
      if (showFundingWhenEmpty) setShowFunding(true);
      logEvent("balance.refresh.skipped", { reason: "missing_or_invalid_public_address" });
      return;
    }
    setBalanceLoading(true);
    try {
      const balance = await readRlusdBalance(address);
      setRlusdBalance(balance);
      if (balance <= 0 && showFundingWhenEmpty) setShowFunding(true);
      logEvent("balance.refresh.success", { address: shortAddress(address), balance });
    } catch (error) {
      setSetupError(error?.message || "Could not read the RLUSD balance.");
      logEvent("balance.refresh.failed", { error });
    } finally {
      setBalanceLoading(false);
    }
  };

  const handleConnectedXrplAccount = async (account, walletId = "xrplconnect") => {
    if (!account?.address?.startsWith("r")) {
      throw new Error("XRPL Connect did not return a valid XRPL address.");
    }
    setSetupError("");
    setSigningWallet(null);
    setWalletProvider("xrplconnect");
    setWalletAddress(account.address);
    setDashboardView("employer");
    setScreen("dashboard");
    logEvent("wallet.setup.success", {
      method: "xrplconnect",
      walletId,
      walletAddress: shortAddress(account.address),
    });
    await refreshBalance(account.address, { showFundingWhenEmpty: false });
  };

  const ensureXrplConnectManager = async () => {
    if (xrplConnectManagerRef.current) {
      return xrplConnectManagerRef.current;
    }

    const {
      WalletManager,
      XamanAdapter,
      CrossmarkAdapter,
      GemWalletAdapter,
      XyraAdapter,
    } = await getXrplConnect();

    const manager = new WalletManager({
      adapters: [
        new XamanAdapter(),
        new CrossmarkAdapter(),
        new GemWalletAdapter(),
        new XyraAdapter(),
      ],
      network: "mainnet",
      autoConnect: false,
    });

    manager.on("connect", (account) => {
      handleConnectedXrplAccount(account, manager.wallet?.id || "xrplconnect").catch((error) => {
        setSetupError(error?.message || "Could not connect XRPL wallet.");
        logEvent("wallet.setup.failed", { method: "xrplconnect", error });
      });
    });

    manager.on("accountChanged", (account) => {
      handleConnectedXrplAccount(account, manager.wallet?.id || "xrplconnect").catch((error) => {
        setSetupError(error?.message || "Could not update XRPL wallet.");
        logEvent("wallet.account_changed.failed", { method: "xrplconnect", error });
      });
    });

    manager.on("disconnect", () => {
      resetWallet();
    });

    xrplConnectManagerRef.current = manager;
    setXrplConnectManager(manager);
    return manager;
  };

  const finishSetup = async () => {
    logEvent("wallet.setup.submitted", {
      method: localDesktop ? method : "xrplconnect",
      accessLength: localDesktop ? accessInput.trim().length : 0,
      runtime: localDesktop ? "desktop" : "web",
    });

    try {
      if (localDesktop) {
        const wallet = createWalletFromInput(method, accessInput, expectedAddress);
        setSetupError("");
        setSigningWallet(wallet);
        setWalletProvider("local");
        setWalletAddress(wallet.address);
        setDashboardView("employer");
        setScreen("dashboard");
        logEvent("wallet.setup.success", { method, runtime: "desktop", walletAddress: shortAddress(wallet.address) });
        await refreshBalance(wallet.address, { showFundingWhenEmpty: false });
        return;
      }

      const manager = await ensureXrplConnectManager();
      if (manager.connected && manager.account?.address) {
        await handleConnectedXrplAccount(manager.account, manager.wallet?.id || "xrplconnect");
        return;
      }
      const connector = xrplConnectorRef.current;
      if (!connector) {
        throw new Error("XRPL Connect is still loading. Try again in a moment.");
      }
      connector.setWalletManager(manager);
      await connector.open();
    } catch (error) {
      setSigningWallet(null);
      setWalletProvider("");
      setSetupError(error?.message || (localDesktop ? "Could not import wallet." : "Could not connect XRPL wallet."));
      logEvent("wallet.setup.failed", { method: localDesktop ? method : "xrplconnect", runtime: localDesktop ? "desktop" : "web", error });
    }
  };

  const savePerson = (draft) => {
    const next = { ...draft, payMode: draft.payMode || "weekly", weeklyPay: draft.weeklyPay ?? draft.amount ?? "16", hourlyPay: draft.hourlyPay ?? "20", hoursPerWeek: draft.hoursPerWeek ?? "40", id: draft.id || `person-${Date.now()}`, paidCount: draft.paidCount || 0, nextRunAt: draft.nextRunAt || null };
    const schedule = getSchedule(next);
    setPeople((current) => draft.id ? current.map((person) => person.id === draft.id ? next : person) : [...current, next]);
    setSelectedId(next.id);
    setEditorOpen(false);
    setEditingPerson(null);
    setPaymentMessage("");
    addHistoryItem(setHistory, { status: "success", title: draft.id ? "Person updated" : "Person added", detail: `${next.name} - ${money(getSchedule(next).weeklyPay, 2)} weekly total, paid every ${getSchedule(next).frequencyLabel}` });
    logEvent(draft.id ? "person.updated" : "person.added", {
      id: next.id,
      name: next.name,
      address: next.address ? shortAddress(next.address) : "none",
      payMode: next.payMode,
      weeklyPay: schedule.weeklyPay,
      perPayment: schedule.perPayment,
      frequency: schedule.frequencyLabel,
      paymentsPerWeek: schedule.payments,
    });
  };

  const togglePlan = (id) => {
    const person = people.find((item) => item.id === id);
    if (!person) return;

    if (person.active) {
      setPeople((current) => current.map((item) => item.id === id ? { ...item, active: false, nextRunAt: null } : item));
      setPaymentMessage(`${person.name}'s plan is paused.`);
      addHistoryItem(setHistory, { status: "paused", title: "Plan paused", detail: person.name });
      logEvent("plan.paused", { id: person.id, name: person.name });
      return;
    }

    const ready = Boolean((walletProvider === "xrplconnect" || signingWallet) && person.address?.startsWith("r"));
    setPeople((current) => current.map((item) => item.id === id ? { ...item, active: true, nextRunAt: ready ? Date.now() : null } : item));
    setPaymentMessage(ready ? `${person.name}'s plan started. First payment prompt is opening.` : `${person.name}'s plan started. Connect a wallet and add a destination address to send payments.`);
    addHistoryItem(setHistory, { status: ready ? "success" : "waiting", title: "Plan started", detail: ready ? `${person.name} - first payment queued now` : `${person.name} - waiting for payer wallet and destination` });
    logEvent("plan.started", {
      id: person.id,
      name: person.name,
      ready,
      hasSigningWallet: Boolean(walletProvider === "xrplconnect" || signingWallet),
      hasDestination: Boolean(person.address?.startsWith("r")),
      schedule: getSchedule(person),
    });
    if (ready) window.setTimeout(() => payInstallment({ ...person, active: true, nextRunAt: Date.now() }, "scheduled"), 150);
  };

  const payInstallment = async (person, source = "manual") => {
    const schedule = getSchedule(person);
    const paidCount = Number(person.paidCount || 0);
    logEvent("payment.installment.requested", {
      source,
      personId: person.id,
      name: person.name,
      paidCount,
      plannedPayments: schedule.payments,
      perPayment: schedule.perPayment,
      sourceTag: SOURCE_TAG,
      payer: walletAddress ? shortAddress(walletAddress) : "none",
      destination: person.address ? shortAddress(person.address) : "none",
    });

    if (paidCount >= schedule.payments) {
      setPeople((current) => current.map((item) => item.id === person.id ? { ...item, active: false, nextRunAt: null } : item));
      addHistoryItem(setHistory, { status: "success", title: "Plan complete", detail: `${person.name} has received all planned installments.` });
      logEvent("payment.installment.skipped", { reason: "plan_complete", personId: person.id, name: person.name });
      return;
    }

    if (!(walletProvider === "xrplconnect" || signingWallet) || !person.address?.startsWith("r")) {
      setPaymentMessage(`${person.name} needs a connected wallet and destination address.`);
      addHistoryItem(setHistory, { status: "waiting", title: "Payment waiting", detail: `${person.name} needs a connected wallet and destination address.` });
      logEvent("payment.installment.blocked", {
        reason: "missing_wallet_or_destination",
        hasSigningWallet: Boolean(walletProvider === "xrplconnect" || signingWallet),
        hasDestination: Boolean(person.address?.startsWith("r")),
      });
      return;
    }

    setPaymentMessage(walletProvider === "xrplconnect" ? "Confirm the installment in your XRPL wallet..." : "Signing and submitting the installment from the connected wallet...");
    addHistoryItem(setHistory, { status: "waiting", title: source === "manual" ? "Manual payment started" : "Scheduled payment started", detail: `${person.name} - ${money(schedule.perPayment, 4)} - source tag ${SOURCE_TAG}` });
    logEvent("payment.local_signing.started", {
      transactionType: "Payment",
      account: shortAddress(walletAddress),
      destination: shortAddress(person.address),
      sourceTag: SOURCE_TAG,
      amount: tokenAmount(schedule.perPayment),
      issuer: RLUSD_ISSUER,
    });
    try {
      const submitter = walletProvider === "xrplconnect" ? submitXrplConnectRlusdPayment : submitRlusdPayment;
      const { result, hash } = await submitter(walletProvider === "xrplconnect" ? {
        manager: xrplConnectManagerRef.current,
        account: walletAddress,
        destination: person.address,
        amount: tokenAmount(schedule.perPayment),
      } : {
        wallet: signingWallet,
        destination: person.address,
        amount: tokenAmount(schedule.perPayment),
      });
      const tx = result?.result || result || {};
      const txHash = hash || tx.hash;
      const nextPaidCount = paidCount + 1;
      const complete = nextPaidCount >= schedule.payments;
      setPeople((current) => current.map((item) => item.id === person.id ? {
        ...item,
        paidCount: nextPaidCount,
        active: complete ? false : item.active,
        nextRunAt: complete ? null : Date.now() + getFrequencyMs(item),
      } : item));
      setPaymentMessage(txHash ? `Payment submitted: ${txHash.slice(0, 10)}...` : "Payment submitted.");
      addHistoryItem(setHistory, { status: "success", title: complete ? "Final payment submitted" : "Payment submitted", detail: txHash ? `${person.name} - ${money(schedule.perPayment, 4)} - tag ${SOURCE_TAG} - ${txHash}` : `${person.name} - ${money(schedule.perPayment, 4)} - tag ${SOURCE_TAG}` });
      logEvent("payment.submitted", {
        personId: person.id,
        name: person.name,
        hash: txHash || null,
        nextPaidCount,
        complete,
        nextRunAt: complete ? null : Date.now() + getFrequencyMs(person),
      });
    } catch (error) {
      setPaymentMessage(error?.message || "Payment was not submitted.");
      setPeople((current) => current.map((item) => item.id === person.id ? { ...item, nextRunAt: Date.now() + 60000 } : item));
      addHistoryItem(setHistory, { status: "failed", title: "Payment not submitted", detail: `${person.name} - ${error?.message || "Wallet confirmation was cancelled."}` });
      logEvent("payment.failed", { personId: person.id, name: person.name, source, error, retryAt: Date.now() + 60000 });
    }
  };

  useEffect(() => {
    const timer = window.setInterval(() => {
      const duePerson = people.find((person) =>
        person.active &&
        person.nextRunAt &&
        Number(person.nextRunAt) <= Date.now() &&
        Number(person.paidCount || 0) < getSchedule(person).payments
      );
      if (!duePerson || autoPayingRef.current) return;
      logEvent("scheduler.due_person_found", {
        personId: duePerson.id,
        name: duePerson.name,
        nextRunAt: duePerson.nextRunAt,
        paidCount: duePerson.paidCount || 0,
        schedule: getSchedule(duePerson),
      });
      autoPayingRef.current = true;
      payInstallment(duePerson, "scheduled").finally(() => {
        autoPayingRef.current = false;
      });
    }, 10000);

    return () => window.clearInterval(timer);
  }, [people, signingWallet, walletProvider, walletAddress]);
  const resetWallet = () => {
    logEvent("wallet.reset", { previousWallet: walletAddress ? shortAddress(walletAddress) : "none", peopleCount: people.length });
    setScreen("intro");
    setAccessInput("");
    setExpectedAddress("");
    setWalletAddress("");
    setRlusdBalance(0);
    setSigningWallet(null);
    setWalletProvider("");
    setSetupError("");
    setDashboardView("employer");
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&family=Playfair+Display:wght@600;700&display=swap');
        * { box-sizing: border-box; }
        body {
          margin: 0;
          background:
            linear-gradient(90deg, rgba(31,45,36,.04) 1px, transparent 1px),
            linear-gradient(180deg, rgba(31,45,36,.04) 1px, transparent 1px),
            ${COLORS.paper};
          background-size: 72px 72px;
          color: ${COLORS.ink};
          font-family: 'Inter', sans-serif;
        }
        button, input, select { font: inherit; }
        button { cursor: pointer; }
        button:disabled { cursor: not-allowed; opacity: .55; }
        .center-screen { min-height: 100vh; display: grid; place-items: center; padding: 28px; position: relative; overflow: hidden; }
        .intro-screen { background: ${COLORS.paper}; }
        .intro-card, .setup-card { width: min(100%, 540px); position: relative; z-index: 1; }
        .intro-card { padding: 46px 48px; background: rgba(255,249,236,.9); border: 1px solid rgba(228,216,193,.9); border-radius: 8px; box-shadow: 0 24px 70px rgba(31,45,36,.12); text-align: center; overflow: hidden; }
        .intro-card > div:first-child { justify-content: center; }
        .brand-lockup { display: flex; align-items: center; gap: 12px; position: relative; z-index: 1; }
        .brand-mark { width: 42px; height: 42px; display: grid; place-items: center; flex: 0 0 auto; background: ${COLORS.ink}; border-radius: 12px; box-shadow: inset 0 0 0 1px rgba(255,255,255,.08); }
        .brand-mark svg { width: 29px; height: 29px; }
        .brand-mark path { stroke: ${COLORS.paper}; stroke-linecap: round; }
        .brand-mark path:nth-child(1) { stroke-width: 6; }
        .brand-mark path:nth-child(2) { stroke-width: 4; }
        .brand-mark path:nth-child(3) { stroke-width: 5; }
        .intro-card .brand-mark { width: 54px; height: 54px; }
        .intro-card .brand-mark svg { width: 38px; height: 38px; }
        .brand-word { font-family: 'Playfair Display', Georgia, serif; font-weight: 700; line-height: 1; letter-spacing: 0; }
        .brand-xrp { margin-top: 3px; font-family: 'IBM Plex Mono', monospace; color: ${COLORS.coral}; font-size: 9px; letter-spacing: .35em; }
        .brand-tagline { margin-top: 8px; color: ${COLORS.muted}; font-size: 12px; }
        .eyebrow { margin: 0 0 8px; text-transform: uppercase; letter-spacing: .16em; font-size: 10px; font-weight: 700; color: ${COLORS.coral}; font-family: 'IBM Plex Mono', monospace; }
        h1, h2, h3, p { margin-top: 0; }
        h1, h2, h3 { font-family: 'Playfair Display', Georgia, serif; font-weight: 700; letter-spacing: 0; }
        h1 { font-size: clamp(42px, 6vw, 65px); line-height: .98; margin-bottom: 20px; }
        h1 em { color: ${COLORS.coral}; font-style: italic; }
        h2 { font-size: 30px; line-height: 1.05; margin-bottom: 10px; }
        h3 { font-size: 24px; margin: 0; }
        .intro-copy, .section-copy { color: ${COLORS.muted}; line-height: 1.65; font-size: 14px; }
        .intro-copy { max-width: 360px; margin: 0 auto 28px; }
        .intro-note, .security-note, .footer-note { color: ${COLORS.muted}; font-size: 11px; }
        .intro-note { margin-top: 20px; }
        .intro-connect-form { display: grid; gap: 14px; max-width: 390px; margin: 0 auto; text-align: left; }
        .intro-connect-form .button { width: 100%; }
        .xrpl-connector { display: none; }
        .button { border: 0; border-radius: 8px; padding: 13px 18px; font-weight: 700; color: ${COLORS.ink}; transition: transform .15s ease, box-shadow .15s ease, background .15s ease; }
        .button:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 8px 18px rgba(52,63,53,.12); }
        .button-primary { background: ${COLORS.coral}; color: #fff8ec; }
        .button-secondary { background: ${COLORS.card}; border: 1px solid ${COLORS.line}; }
        .button-soft { background: ${COLORS.mint}; color: ${COLORS.ink}; }
        .button-ghost { padding: 8px 10px; background: transparent; color: ${COLORS.muted}; font-size: 12px; }
        .button-small { padding: 9px 12px; font-size: 12px; background: ${COLORS.mint}; color: ${COLORS.mintDark}; }
        .button span { margin-left: 8px; font-size: 16px; }
        .intro-decoration { position: absolute; border-radius: 50%; filter: blur(1px); opacity: .65; }
        .decoration-one { width: 260px; height: 260px; top: -90px; right: 12%; background: ${COLORS.butter}; }
        .decoration-two { width: 330px; height: 330px; bottom: -170px; left: 4%; background: ${COLORS.stone}; }
        .setup-screen { background: ${COLORS.paper}; }
        .setup-card { max-width: 480px; padding: 30px; background: ${COLORS.card}; border: 1px solid ${COLORS.line}; border-radius: 24px; box-shadow: 0 18px 50px rgba(72,74,56,.08); }
        .progress-dots { display: flex; gap: 6px; margin: 38px 0 32px; }
        .progress-dots span { width: 32px; height: 4px; border-radius: 4px; background: ${COLORS.line}; }
        .progress-dots .active { background: ${COLORS.coral}; }
        .setup-card h2 { font-size: 42px; margin-bottom: 14px; }
        .form-stack { display: grid; gap: 16px; margin: 24px 0; }
        .field { display: grid; gap: 7px; min-width: 0; }
        .field-label { font-size: 11px; font-weight: 700; color: ${COLORS.ink}; }
        .field-help { color: ${COLORS.muted}; font-size: 10px; line-height: 1.4; }
        input, select { width: 100%; min-height: 43px; padding: 10px 12px; border: 1px solid ${COLORS.line}; border-radius: 10px; background: #fff; color: ${COLORS.ink}; outline: none; }
        input:focus, select:focus { border-color: ${COLORS.mintDark}; box-shadow: 0 0 0 3px rgba(185,221,203,.35); }
        .secret-input-wrap { position: relative; }
        .secret-input-wrap input { padding-right: 68px; }
        .secret-toggle { position: absolute; right: 6px; top: 6px; min-height: 31px; padding: 0 10px; border: 1px solid ${COLORS.line}; border-radius: 8px; background: ${COLORS.card}; color: ${COLORS.mintDark}; font-size: 11px; font-weight: 700; }
        .setup-card .button { width: 100%; }
        .security-note { margin-top: 18px; line-height: 1.45; text-align: center; }
        .security-note span { color: ${COLORS.coralDark}; font-size: 15px; margin-right: 4px; }
        .error-message, .success-message { padding: 11px 13px; border-radius: 10px; font-size: 12px; line-height: 1.4; margin-bottom: 14px; }
        .error-message { color: ${COLORS.coralDark}; background: #fae9e2; }
        .success-message { color: ${COLORS.mintDark}; background: #e3f2e9; margin-top: 16px; }
        .app-shell { min-height: 100vh; background: transparent; position: relative; overflow: hidden; }
        .topbar { position: relative; z-index: 2; height: 74px; padding: 0 clamp(20px, 5vw, 76px); display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid ${COLORS.line}; background: rgba(246,241,230,.82); backdrop-filter: blur(12px); }
        .topbar-right, .wallet-chip, .welcome-row, .balance-actions, .card-heading, .details-top, .details-actions, .payer-strip { display: flex; align-items: center; }
        .topbar-right { gap: 12px; }
        .wallet-chip, .live-pill { gap: 8px; color: ${COLORS.muted}; font-size: 12px; }
        .wallet-chip { padding: 8px 10px; background: ${COLORS.card}; border: 1px solid ${COLORS.line}; border-radius: 10px; font-family: monospace; }
        .online-dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; background: #65aa7c; box-shadow: 0 0 0 3px rgba(101,170,124,.15); }
        .brand-pattern { position: absolute; pointer-events: none; z-index: 0; }
        .pattern-wave { left: -24vw; top: 96px; width: 150vw; height: 120px; opacity: .24; overflow: visible; }
        .pattern-wave svg { width: 116%; height: 100%; margin-left: -8%; animation: brandWaveDrift 18s ease-in-out infinite alternate; }
        .pattern-wave path { fill: none; stroke: ${COLORS.ink}; stroke-width: 1.2; stroke-linecap: round; stroke-dasharray: 28 18 84 22; animation: brandWaveFlow var(--wave-speed, 11s) linear infinite; }
        .pattern-wave path:nth-child(1), .pattern-wave path:nth-child(2) { stroke: ${COLORS.coral}; }
        .pattern-wave path:nth-child(1) { --wave-speed: 9s; }
        .pattern-wave path:nth-child(2) { --wave-speed: 10.5s; animation-direction: reverse; }
        .pattern-wave path:nth-child(3) { --wave-speed: 12s; }
        .pattern-wave path:nth-child(4) { --wave-speed: 13.5s; animation-direction: reverse; }
        .pattern-wave path:nth-child(5) { --wave-speed: 15s; }
        .pattern-wave path:nth-child(6) { --wave-speed: 16.5s; animation-direction: reverse; }
        .pattern-dots { right: 7%; top: 132px; width: 134px; height: 96px; opacity: .34; background-image: radial-gradient(circle, ${COLORS.coral} 1.8px, transparent 2px); background-size: 18px 18px; animation: dotPulse 4.6s ease-in-out infinite alternate; }
        .pattern-rings { right: 6%; top: 190px; width: 170px; height: 170px; border-radius: 50%; border: 1px solid rgba(234,215,154,.62); box-shadow: 0 0 0 18px rgba(234,215,154,.08), 0 0 0 37px rgba(234,215,154,.38), 0 0 0 57px rgba(234,215,154,.24); opacity: .75; }
        .pattern-lines { right: 8%; bottom: 40px; width: 190px; height: 130px; opacity: .26; background: repeating-linear-gradient(135deg, transparent 0 13px, rgba(31,45,36,.72) 13px 14px, transparent 14px 27px); }
        .pattern-lines:before, .pattern-lines:after { content: ""; position: absolute; width: 2px; height: 76px; background: ${COLORS.coral}; transform: rotate(45deg); }
        .pattern-lines:before { right: 44px; top: 14px; }
        .pattern-lines:after { right: 88px; bottom: 8px; opacity: .55; }
        .intro-card .pattern-rings { top: 24px; right: -62px; width: 130px; height: 130px; opacity: .52; }
        .intro-screen > .pattern-wave { top: 18%; opacity: .2; }
        .intro-screen > .pattern-dots { left: 8%; right: auto; top: auto; bottom: 12%; }
        .employee-app > .pattern-dots { top: 260px; }
        .proof-app > .pattern-wave { opacity: .16; }
        @keyframes brandWaveDrift { 0% { transform: translateX(-4%); } 100% { transform: translateX(4%); } }
        @keyframes brandWaveFlow { to { stroke-dashoffset: -260; } }
        @keyframes dotPulse { 0% { opacity: .18; transform: translateY(0); } 100% { opacity: .42; transform: translateY(-8px); } }
        .dashboard-content { position: relative; z-index: 1; max-width: 1200px; margin: 0 auto; padding: 54px clamp(20px, 5vw, 76px) 40px; }
        .welcome-row { justify-content: space-between; gap: 20px; margin-bottom: 30px; }
        .welcome-row h1 { font-size: clamp(38px, 5vw, 58px); margin-bottom: 10px; }
        .muted-line { margin: 0; color: ${COLORS.muted}; font-size: 13px; }
        .live-pill { padding: 8px 12px; border-radius: 99px; background: rgba(234,215,154,.35); color: ${COLORS.ink}; font-weight: 700; }
        .balance-card { display: flex; align-items: flex-end; justify-content: space-between; gap: 20px; padding: 30px 34px; min-height: 190px; border-radius: 8px; background: ${COLORS.ink}; color: #fffdf8; box-shadow: 0 18px 40px rgba(36,51,45,.16); }
        .balance-card .eyebrow, .balance-card .muted-line { color: #c1d0c7; }
        .balance-number { font: 600 clamp(48px, 7vw, 82px)/1 'Playfair Display', Georgia, serif; margin: 12px 0 10px; }
        .balance-actions { gap: 10px; flex-wrap: wrap; }
        .balance-card .button-secondary { background: #fffdf8; border-color: #fffdf8; }
        .balance-card .button-soft { background: ${COLORS.mint}; }
        .stream-widget { position: relative; display: grid; gap: 22px; margin-bottom: 14px; padding: 28px 30px 24px; border: 1px solid rgba(53,70,58,.9); border-radius: 12px; background: radial-gradient(circle at 82% 20%, rgba(234,215,154,.14), transparent 32%), ${COLORS.ink2}; color: #fff8ec; box-shadow: 0 24px 54px rgba(31,45,36,.24); overflow: hidden; }
        .stream-widget-rings { position: absolute; right: -82px; top: 28px; width: 170px; height: 170px; border-radius: 50%; border: 1px solid rgba(234,215,154,.44); box-shadow: 0 0 0 18px rgba(234,215,154,.08), 0 0 0 36px rgba(234,215,154,.04); }
        .stream-top, .stream-stats, .stream-footer { position: relative; z-index: 1; }
        .stream-top { display: flex; justify-content: space-between; gap: 24px; align-items: flex-start; }
        .stream-label, .stream-live { font-family: 'IBM Plex Mono', monospace; font-size: 10px; letter-spacing: .14em; text-transform: uppercase; }
        .stream-label { margin: 0 0 14px; color: #aeb7ad; }
        .stream-live { display: inline-flex; align-items: center; gap: 7px; color: ${COLORS.mint}; }
        .stream-amount { font-family: 'IBM Plex Mono', monospace; font-size: clamp(42px, 7vw, 72px); line-height: 1; letter-spacing: -.03em; }
        .stream-amount span { color: ${COLORS.coral}; }
        .stream-subcopy { margin: 8px 0 0; color: #aeb7ad; font-size: 12px; line-height: 1.5; max-width: 560px; }
        .stream-wave { position: relative; z-index: 1; width: 100%; height: 72px; overflow: visible; }
        .stream-wave path { fill: none; }
        .stream-wave-base { stroke: rgba(246,241,230,.2); stroke-width: 1; }
        .stream-wave-line { stroke: ${COLORS.coral}; stroke-width: 2; stroke-linecap: round; stroke-dasharray: 130 28 18 28; animation: streamLineFlow 3.2s linear infinite; }
        .stream-wave circle { fill: ${COLORS.coral}; animation: streamDot 2.4s ease-in-out infinite alternate; }
        .stream-stats { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; padding-top: 18px; border-top: 1px solid rgba(228,216,193,.18); }
        .stream-stats strong { display: block; font-family: 'IBM Plex Mono', monospace; font-size: 16px; color: #fff8ec; word-break: break-word; }
        .stream-stats span { display: block; margin-top: 5px; color: #aeb7ad; font-size: 9px; letter-spacing: .08em; text-transform: uppercase; }
        .stream-footer { display: flex; justify-content: space-between; align-items: center; gap: 16px; flex-wrap: wrap; }
        .stream-footer code { color: #aeb7ad; word-break: break-all; }
        .stream-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .stream-widget .button-secondary { background: #fff8ec; border-color: #fff8ec; }
        .stream-widget .button-soft { background: ${COLORS.mint}; }
        @keyframes streamLineFlow { to { stroke-dashoffset: -204; } }
        @keyframes streamDot { 0% { transform: translateY(0); } 100% { transform: translateY(-16px); } }
        .payer-strip { justify-content: space-between; gap: 18px; padding: 17px 20px; margin: 14px 0 34px; border: 1px solid ${COLORS.line}; border-radius: 16px; background: ${COLORS.card}; }
        .payer-strip strong { display: block; font: 600 17px Georgia, serif; }
        .payer-strip span { display: block; margin-top: 4px; color: ${COLORS.muted}; font-size: 11px; }
        .content-grid { display: grid; grid-template-columns: minmax(300px, .8fr) minmax(420px, 1.2fr); gap: 16px; align-items: stretch; }
        .people-card, .details-card, .editor-card { padding: 24px; border: 1px solid ${COLORS.line}; border-radius: 20px; background: ${COLORS.card}; }
        .card-heading { justify-content: space-between; gap: 12px; margin-bottom: 22px; }
        .card-heading h2 { font-size: 25px; margin: 0; }
        .card-actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
        .people-list { display: grid; gap: 7px; }
        .person-row { display: grid; grid-template-columns: 38px minmax(0, 1fr) auto 8px; align-items: center; gap: 10px; width: 100%; padding: 11px; border: 1px solid transparent; border-radius: 14px; background: transparent; text-align: left; color: ${COLORS.ink}; }
        .person-row:hover, .person-row.selected { background: #f3f7f1; border-color: ${COLORS.mint}; }
        .avatar, .large-avatar { display: grid; place-items: center; border-radius: 13px; background: ${COLORS.butter}; color: ${COLORS.coralDark}; font-weight: 700; }
        .avatar { width: 38px; height: 38px; }
        .person-info, .person-amount { min-width: 0; display: grid; gap: 3px; }
        .person-info b, .person-amount b { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; }
        .person-info small, .person-amount small { color: ${COLORS.muted}; font-size: 10px; }
        .person-amount { text-align: right; }
        .status-dot { width: 7px; height: 7px; border-radius: 50%; background: ${COLORS.line}; }
        .status-dot.on { background: #65aa7c; }
        .empty-people, .details-empty { min-height: 290px; display: grid; place-items: center; align-content: center; text-align: center; color: ${COLORS.muted}; }
        .empty-people p, .details-empty p { max-width: 240px; line-height: 1.55; font-size: 13px; }
        .empty-scribble, .empty-sun { color: ${COLORS.coral}; font: 34px Georgia, serif; margin-bottom: 12px; }
        .details-top { gap: 14px; position: relative; }
        .large-avatar { width: 56px; height: 56px; border-radius: 18px; font-size: 22px; }
        .details-top h2 { font-size: 30px; margin: 0 0 4px; }
        .edit-button { margin-left: auto; }
        .text-button { border: 0; padding: 4px; background: transparent; color: ${COLORS.coralDark}; font-size: 12px; font-weight: 700; }
        .address-line { display: flex; justify-content: space-between; gap: 12px; padding: 15px 0; margin: 20px 0; border-top: 1px solid ${COLORS.line}; border-bottom: 1px solid ${COLORS.line}; color: ${COLORS.muted}; font-size: 11px; }
        code { font-family: monospace; color: ${COLORS.ink}; }
        .detail-highlight { display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; gap: 16px; padding: 20px; border-radius: 16px; background: #f3eee2; }
        .detail-highlight strong { display: block; font: 600 28px Georgia, serif; margin: 5px 0; }
        .detail-highlight small { display: block; color: ${COLORS.muted}; font-size: 10px; }
        .highlight-arrow { color: ${COLORS.coral}; font-size: 28px; }
        .details-actions { gap: 10px; flex-wrap: wrap; margin-top: 20px; }
        .plan-meter { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; margin-top: 14px; }
        .plan-meter > div { padding: 12px; border: 1px solid ${COLORS.line}; border-radius: 12px; background: #fff; }
        .plan-meter span, .plan-meter strong { display: block; }
        .plan-meter span { color: ${COLORS.muted}; font-size: 10px; }
        .plan-meter strong { margin-top: 4px; font-size: 12px; }
        .inline-note, .safe-payment-note { color: ${COLORS.muted}; font-size: 11px; line-height: 1.5; }
        .safe-payment-note { padding: 12px; margin-top: 20px; background: #f6f2e8; border-radius: 10px; }
        .safe-payment-note span { color: ${COLORS.mintDark}; margin-right: 6px; }
        .footer-note { max-width: 760px; margin: 24px auto 0; text-align: center; line-height: 1.5; }
        .history-panel { margin-top: 16px; padding: 24px; border: 1px solid ${COLORS.line}; border-radius: 20px; background: ${COLORS.card}; }
        .history-list { display: grid; gap: 8px; }
        .history-row { display: flex; justify-content: space-between; gap: 16px; padding: 12px; border: 1px solid ${COLORS.line}; border-radius: 12px; background: #fff; }
        .history-row b, .history-row span, .history-row time { display: block; }
        .history-row b { font-size: 13px; }
        .history-row span, .history-row time { color: ${COLORS.muted}; font-size: 11px; line-height: 1.4; }
        .history-row.success { border-color: ${COLORS.mint}; }
        .history-row.failed { border-color: #efb49f; background: #fff7f3; }
        .debug-log-list { display: grid; gap: 8px; max-height: 310px; overflow: auto; }
        .debug-log-row { display: grid; grid-template-columns: 150px 180px minmax(0, 1fr); gap: 10px; align-items: start; padding: 10px; border: 1px solid ${COLORS.line}; border-radius: 10px; background: #fff; }
        .debug-log-row time, .debug-log-row b, .debug-log-row code { font-size: 10px; line-height: 1.4; }
        .debug-log-row time { color: ${COLORS.muted}; }
        .debug-log-row b { color: ${COLORS.ink}; }
        .debug-log-row code { white-space: pre-wrap; word-break: break-word; color: ${COLORS.muted}; }
        .editor-card { grid-column: 1 / -1; }
        .editor-heading { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 22px; }
        .editor-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
        .pay-plan-box { margin: 22px 0; padding: 18px; border-radius: 16px; background: #f3eee2; }
        .pay-plan-title { font: 600 18px Georgia, serif; margin-bottom: 16px; }
        .mode-toggle { display: inline-flex; align-items: center; gap: 9px; margin-bottom: 16px; padding: 9px 11px; border: 1px solid ${COLORS.line}; border-radius: 10px; background: #fff; color: ${COLORS.ink}; font-size: 12px; font-weight: 700; }
        .mode-toggle input { width: 16px; min-height: 16px; padding: 0; accent-color: ${COLORS.mintDark}; }
        .plan-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .input-with-symbol { position: relative; }
        .input-with-symbol span { position: absolute; left: 12px; top: 12px; color: ${COLORS.muted}; }
        .input-with-symbol input { padding-left: 26px; }
        .schedule-summary { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; padding-top: 18px; margin-top: 18px; border-top: 1px solid ${COLORS.line}; }
        .schedule-summary > div { display: grid; gap: 5px; }
        .summary-label { color: ${COLORS.muted}; font-size: 10px; }
        .schedule-summary strong { font: 600 18px Georgia, serif; }
        .modal-backdrop { position: fixed; z-index: 10; inset: 0; display: grid; place-items: center; padding: 20px; background: rgba(36,51,45,.35); }
        .modal-card { width: min(100%, 430px); position: relative; padding: 34px; border-radius: 22px; background: ${COLORS.card}; box-shadow: 0 20px 70px rgba(36,51,45,.25); }
        .modal-close { position: absolute; top: 15px; right: 17px; border: 0; background: transparent; color: ${COLORS.muted}; font-size: 26px; }
        .modal-icon { color: ${COLORS.coral}; font-size: 40px; margin-bottom: 20px; }
        .modal-card h2 { font-size: 38px; }
        .funding-steps { display: grid; gap: 13px; margin: 22px 0 26px; }
        .funding-steps > div { display: grid; grid-template-columns: 25px 1fr; gap: 9px; align-items: start; color: ${COLORS.muted}; font-size: 12px; line-height: 1.45; }
        .funding-steps b { display: grid; place-items: center; width: 23px; height: 23px; border-radius: 50%; background: ${COLORS.mint}; color: ${COLORS.mintDark}; font-size: 11px; }
        .employee-app { background: linear-gradient(180deg, ${COLORS.paper} 0%, #f4efe4 100%); }
        .employee-content { max-width: 1000px; display: flex; flex-direction: column; gap: 18px; }
        .employee-hero { display: flex; align-items: flex-start; justify-content: space-between; gap: 20px; flex-wrap: wrap; }
        .employee-hero .eyebrow { display: flex; align-items: center; gap: 8px; }
        .employee-hero h1 { font-size: clamp(38px, 5vw, 58px); margin-bottom: 10px; }
        .employee-balance-card { display: grid; gap: 22px; padding: 30px 34px; border-radius: 24px; background: ${COLORS.ink}; color: #fffdf8; box-shadow: 0 18px 40px rgba(36,51,45,.16); }
        .employee-balance-card .eyebrow { color: #c1d0c7; }
        .employee-balance-card p { margin: 0; color: #c1d0c7; font-size: 13px; }
        .employee-balance-top, .employee-balance-footer { display: flex; align-items: flex-start; justify-content: space-between; gap: 20px; flex-wrap: wrap; }
        .employee-balance-footer { align-items: flex-end; padding-top: 18px; border-top: 1px solid rgba(255,253,248,.15); }
        .employee-balance-footer code { color: #c1d0c7; }
        .employee-balance-footer > div { display: grid; justify-items: end; gap: 8px; }
        .employee-balance-number { font: 600 clamp(54px, 8vw, 86px)/1 'Fraunces', Georgia, serif; letter-spacing: -.04em; margin: 8px 0 12px; }
        .employee-balance-number span { color: ${COLORS.mint}; }
        .employee-live-tag { display: inline-flex; align-items: center; gap: 7px; width: fit-content; padding: 7px 10px; border-radius: 999px; background: #e7f2e9; color: ${COLORS.mintDark}; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .employee-stat-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
        .employee-card { padding: 24px; border: 1px solid ${COLORS.line}; border-radius: 20px; background: ${COLORS.card}; box-shadow: 0 10px 24px rgba(72,74,56,.07); }
        .employee-card strong { display: block; font: 600 30px Georgia, serif; margin-bottom: 6px; color: ${COLORS.ink}; }
        .employee-card span, .employee-card small { color: ${COLORS.muted}; font-size: 12px; }
        .employee-progress { height: 9px; overflow: hidden; margin: 16px 0 9px; border-radius: 999px; background: #ece7dc; }
        .employee-progress div { height: 100%; border-radius: inherit; background: ${COLORS.mintDark}; transition: width .2s ease; }
        .employee-meta-row { display: flex; gap: 30px; margin-top: 18px; flex-wrap: wrap; }
        .employee-meta-row small, .employee-meta-row b { display: block; }
        .employee-meta-row b { margin-top: 3px; font-size: 13px; }
        .employee-history-card .card-heading { margin-bottom: 16px; }
        .employee-table-wrap { overflow: auto; }
        .employee-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .employee-table th { padding: 10px 8px; border-bottom: 1px solid ${COLORS.line}; color: ${COLORS.muted}; text-align: left; text-transform: uppercase; letter-spacing: .08em; font-size: 10px; }
        .employee-table td { padding: 12px 8px; border-bottom: 1px solid #eee8db; color: ${COLORS.ink}; }
        .employee-table td:nth-child(3) { color: ${COLORS.muted}; font-family: monospace; }
        .employee-table td span { display: inline-flex; padding: 4px 9px; border-radius: 999px; background: #e7f2e9; color: ${COLORS.mintDark}; font-size: 11px; font-weight: 700; }
        .proof-app { background: #f4ead8; }
        .proof-topbar { background: rgba(244,234,216,.85); border-bottom: 0; }
        .proof-content { max-width: 900px; margin: 0 auto; padding: 18px clamp(20px, 4vw, 44px) 44px; display: flex; flex-direction: column; gap: 18px; }
        .proof-heading { display: flex; justify-content: space-between; align-items: flex-start; gap: 20px; flex-wrap: wrap; }
        .proof-heading .eyebrow { display: flex; align-items: center; gap: 8px; color: ${COLORS.coralDark}; }
        .proof-heading h1 { color: #201e1d; font-size: clamp(36px, 5vw, 52px); margin-bottom: 8px; }
        .proof-heading p { max-width: 540px; margin: 0; color: #615a51; line-height: 1.5; }
        .proof-pill { display: inline-flex; align-items: center; padding: 7px 12px; border-radius: 999px; background: #eef8df; color: ${COLORS.mintDark}; font-size: 11px; white-space: nowrap; }
        .proof-reference { display: grid; gap: 18px; padding: 22px 18px; border-radius: 28px; background: #201e1d; color: #fff8ec; }
        .proof-reference-top { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding-bottom: 16px; border-bottom: 1px solid rgba(255,248,236,.14); }
        .proof-reference-top p, .proof-reference small { margin: 0; color: rgba(255,248,236,.55); font-size: 11px; letter-spacing: .1em; text-transform: uppercase; }
        .proof-reference-top strong { display: block; margin-top: 4px; font: 600 22px Georgia, serif; letter-spacing: .02em; }
        .proof-reference-top span { display: inline-flex; align-items: center; gap: 7px; padding: 6px 10px; border-radius: 999px; background: rgba(255,248,236,.12); font-size: 11px; font-weight: 700; text-transform: uppercase; white-space: nowrap; }
        .proof-reference-top i { width: 6px; height: 6px; border-radius: 999px; background: ${COLORS.coral}; }
        .proof-reference-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px 28px; }
        .proof-reference b { display: block; margin-top: 4px; font-size: 13px; word-break: break-all; }
        .proof-stat-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
        .proof-card { padding: 20px 14px; border-radius: 28px; background: #eadcc4; box-shadow: 0 4px 14px rgba(46,43,37,.08); }
        .proof-card .eyebrow { color: ${COLORS.coralDark}; }
        .proof-card strong { display: block; color: #201e1d; font: 600 30px Georgia, serif; margin: 8px 0; }
        .proof-card span, .proof-card p { color: #615a51; font-size: 13px; line-height: 1.5; }
        .proof-status { padding: 13px 16px; border-radius: 16px; background: #eef8df; color: ${COLORS.mintDark}; font-size: 13px; line-height: 1.5; }
        .proof-status.error { background: #fae9e2; color: ${COLORS.coralDark}; }
        .proof-projection { padding: 24px 14px; }
        .proof-projection h2, .proof-ledger h2 { font-size: 20px; color: #201e1d; letter-spacing: 0; margin-bottom: 18px; }
        .proof-projection-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 20px; margin-bottom: 18px; }
        .proof-projection-grid small { display: block; color: ${COLORS.muted}; margin-bottom: 5px; }
        .proof-projection-grid strong { font-size: 24px; margin: 0; }
        .proof-ledger { padding: 14px; }
        .proof-ledger-head { display: flex; justify-content: space-between; align-items: center; gap: 16px; flex-wrap: wrap; }
        .proof-ledger-head h2 { margin: 0; }
        .proof-ledger-head > div:last-child { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .proof-disclaimer { max-width: 680px; margin: 0; color: ${COLORS.muted}; font-size: 12px; line-height: 1.5; }
        @media (max-width: 760px) {
          .topbar { height: auto; padding: 18px 20px; gap: 14px; flex-wrap: wrap; }
          .topbar-right { width: 100%; justify-content: space-between; }
          .dashboard-content { padding-top: 32px; }
          .welcome-row, .balance-card, .payer-strip { align-items: flex-start; flex-direction: column; }
          .balance-card { padding: 25px; }
          .content-grid { grid-template-columns: 1fr; }
          .employee-balance-card { padding: 25px; }
          .employee-stat-grid { grid-template-columns: 1fr; }
          .proof-reference-grid, .proof-stat-grid, .proof-projection-grid { grid-template-columns: 1fr; }
          .debug-log-row { grid-template-columns: 1fr; }
          .plan-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 480px) {
          .intro-card, .setup-card, .people-card, .details-card, .editor-card { padding: 22px; }
          .intro-card { border-radius: 20px; }
          .intro-card .brand-mark { width: 42px; height: 42px; font-size: 25px; }
          .detail-highlight { gap: 8px; padding: 14px; }
          .detail-highlight strong { font-size: 22px; }
          .editor-grid, .plan-grid, .schedule-summary { grid-template-columns: 1fr; }
          .schedule-summary { gap: 14px; }
          .person-row { grid-template-columns: 36px minmax(0, 1fr) 8px; }
          .person-amount { display: none; }
        }
      `}</style>
      {screen === "intro" && <Intro method={method} setMethod={setMethod} accessInput={accessInput} setAccessInput={setAccessInput} expectedAddress={expectedAddress} setExpectedAddress={setExpectedAddress} onSubmit={finishSetup} error={setupError} isLocal={localDesktop} connectorRef={xrplConnectorRef} xrplManager={xrplConnectManager} />}
      {screen === "dashboard" && (
        <>
          {editorOpen ? (
            <div className="app-shell"><header className="topbar"><Brand compact /><Button kind="ghost" onClick={() => setEditorOpen(false)}>Back to dashboard</Button></header><main className="dashboard-content"><PersonEditor person={editingPerson} onSave={savePerson} onCancel={() => { setEditorOpen(false); setEditingPerson(null); }} /></main></div>
          ) : dashboardView === "employee" ? (
            <EmployeeDashboard walletAddress={walletAddress} rlusdBalance={rlusdBalance} balanceLoading={balanceLoading} onRefreshBalance={() => refreshBalance()} people={people} onBack={() => setDashboardView("employer")} onExportLogs={exportLogs} onReset={resetWallet} />
          ) : <Dashboard walletAddress={walletAddress} walletProvider={walletProvider} rlusdBalance={rlusdBalance} balanceLoading={balanceLoading} onRefreshBalance={() => refreshBalance()} onOpenFunding={() => setShowFunding(true)} onReset={resetWallet} people={people} onAdd={() => { setEditingPerson(null); setEditorOpen(true); }} selectedId={selectedId} onSelect={setSelectedId} onSave={savePerson} onEdit={(person) => { setEditingPerson(person); setEditorOpen(true); }} onToggle={togglePlan} onPay={payInstallment} paymentMessage={paymentMessage} history={history} onExportLogs={exportLogs} onOpenEmployee={() => setDashboardView("employee")} />}
          {showFunding && <FundingModal onClose={() => setShowFunding(false)} />}
        </>
      )}
    </>
  );
}
